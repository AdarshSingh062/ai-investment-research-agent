import { useEffect, useRef } from "react";
import { AgentStep } from "../types.js";
import { Loader2, CheckCircle2, Circle, AlertCircle, Terminal, HelpCircle } from "lucide-react";

interface ResearchConsoleProps {
  companyName: string;
  steps: AgentStep[];
  currentStepId: string | null;
  error: string | null;
}

export default function ResearchConsole({
  companyName,
  steps,
  currentStepId,
  error,
}: ResearchConsoleProps) {
  const logEndRef = useRef<HTMLDivElement>(null);

  // Auto-scroll the terminal logs to the bottom as they stream in
  useEffect(() => {
    logEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [steps]);

  // Find current active step or last active step's logs
  const activeStep = steps.find((s) => s.id === currentStepId) || steps.find((s) => s.status === "running") || steps.find((s) => s.status === "completed" && s.logs.length > 0);
  const currentLogs = activeStep ? activeStep.logs : [];

  const getStepIcon = (status: AgentStep["status"]) => {
    switch (status) {
      case "completed":
        return <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 animate-pulse" />;
      case "running":
        return <Loader2 className="w-5 h-5 text-sky-400 animate-spin shrink-0" />;
      case "failed":
        return <AlertCircle className="w-5 h-5 text-rose-500 shrink-0" />;
      default:
        return <Circle className="w-5 h-5 text-slate-700 shrink-0" />;
    }
  };

  const getStepBg = (status: AgentStep["status"]) => {
    switch (status) {
      case "completed":
        return "border-emerald-500/20 bg-emerald-500/[0.02]";
      case "running":
        return "border-sky-500/30 bg-sky-500/[0.04]";
      case "failed":
        return "border-rose-500/20 bg-rose-500/[0.02]";
      default:
        return "border-slate-800/80 bg-slate-900/10";
    }
  };

  return (
    <div className="max-w-7xl mx-auto p-4 md:p-8 space-y-6 animate-fade-in" id="research-console">
      {/* Header Banner */}
      <div className="bg-[#0A0A0B]/80 backdrop-blur-md border border-slate-800 p-6 md:p-8 rounded-3xl relative overflow-hidden shadow-xl">
        <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/5 rounded-full blur-3xl -mr-20 -mt-20"></div>
        <div className="relative flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="w-2 h-2 rounded-full bg-sky-400 animate-ping"></span>
              <p className="text-[10px] font-mono text-sky-400 uppercase tracking-widest font-semibold">Agent Session Active</p>
            </div>
            <h1 className="font-display text-2xl md:text-3xl font-extrabold text-white tracking-tight">
              Researching: <span className="text-emerald-400">"{companyName}"</span>
            </h1>
            <p className="text-xs text-slate-400 mt-1 leading-relaxed max-w-2xl">
              Executing Multi-Stage Deep Intelligence, Web Grounding Search, & Financial Synthesis. This will take about 30-40 seconds.
            </p>
          </div>
          {error && (
            <div className="bg-rose-500/10 border border-rose-500/20 text-rose-400 rounded-2xl p-4 text-xs flex items-center gap-2 max-w-sm">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Stages Checklist */}
        <div className="lg:col-span-5 space-y-3">
          <h3 className="text-[10px] uppercase tracking-widest text-slate-500 font-mono font-bold px-1">
            Execution Roadmap
          </h3>
          <div className="space-y-3">
            {steps.map((step) => (
              <div
                key={step.id}
                className={`flex items-start gap-3.5 p-4 rounded-2xl border transition-all duration-300 ${getStepBg(
                  step.status
                )}`}
              >
                <div className="mt-0.5">{getStepIcon(step.status)}</div>
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-200">{step.title}</h4>
                  <p className="text-xs text-slate-400 mt-1.5 leading-relaxed">{step.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Live Terminal Logs */}
        <div className="lg:col-span-7 flex flex-col h-[460px] bg-[#050505] border border-slate-800 rounded-3xl overflow-hidden shadow-2xl">
          {/* Terminal Titlebar */}
          <div className="bg-[#0E0E11] border-b border-slate-800/80 px-5 py-3 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <Terminal className="w-4 h-4 text-emerald-400 animate-pulse" />
              <span className="text-[10px] font-mono font-bold text-slate-300 tracking-widest">
                INVESTMENT_AGENT_ENGINE_LOGS
              </span>
            </div>
            <div className="flex gap-1.5">
              <span className="w-2 h-2 rounded-full bg-slate-800"></span>
              <span className="w-2 h-2 rounded-full bg-slate-800"></span>
              <span className="w-2 h-2 rounded-full bg-emerald-500/40"></span>
            </div>
          </div>

          {/* Terminal Output */}
          <div className="flex-1 overflow-y-auto p-5 font-mono text-[11px] space-y-2 text-slate-300 selection:bg-emerald-500/30">
            {currentLogs.length === 0 ? (
              <div className="text-slate-500 italic h-full flex flex-col items-center justify-center gap-2">
                <Loader2 className="w-5 h-5 text-slate-600 animate-spin" />
                <span>Initializing server process... Waiting for trace stream...</span>
              </div>
            ) : (
              currentLogs.map((log, idx) => {
                // Style warnings, searches, completes uniquely
                let style = "text-slate-300";
                if (log.includes("failed") || log.includes("Error")) style = "text-rose-400 font-bold";
                else if (log.includes("Initiating Google Search")) style = "text-sky-400 font-medium";
                else if (log.includes("completed") || log.includes("completed")) style = "text-emerald-400 font-semibold";
                else if (log.includes("Synthesizing")) style = "text-amber-300";

                return (
                  <div key={idx} className={`${style} leading-relaxed break-words`}>
                    <span className="text-slate-600 mr-2">›</span>
                    {log}
                  </div>
                );
              })
            )}
            <div ref={logEndRef} />
          </div>
        </div>
      </div>
    </div>
  );
}
