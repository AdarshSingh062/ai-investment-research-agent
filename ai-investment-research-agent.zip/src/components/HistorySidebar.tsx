import { ResearchReport, DecisionType } from "../types.js";
import { Trash2, FileText, BarChart3, TrendingUp, HelpCircle, AlertTriangle } from "lucide-react";
import { motion } from "motion/react";

interface HistorySidebarProps {
  reports: ResearchReport[];
  selectedId: string | null;
  onSelectReport: (id: string) => void;
  onDeleteReport: (id: string) => void;
  onClearAll: () => void;
  onNewResearch: () => void;
}

export default function HistorySidebar({
  reports,
  selectedId,
  onSelectReport,
  onDeleteReport,
  onClearAll,
  onNewResearch,
}: HistorySidebarProps) {
  // Calculate quick stats
  const total = reports.length;
  const investCount = reports.filter((r) => r.thesis.decision === "INVEST").length;
  const holdCount = reports.filter((r) => r.thesis.decision === "HOLD").length;
  const passCount = reports.filter((r) => r.thesis.decision === "PASS").length;

  const decisionBadgeStyle = (decision: DecisionType) => {
    switch (decision) {
      case "INVEST":
        return "bg-emerald-500/15 text-emerald-400 border border-emerald-500/30";
      case "HOLD":
        return "bg-amber-500/15 text-amber-400 border border-amber-500/30";
      case "PASS":
        return "bg-rose-500/15 text-rose-400 border border-rose-500/30";
    }
  };

  return (
    <div className="w-full lg:w-80 bg-[#0C0C0E] border-r border-slate-800 flex flex-col h-full overflow-hidden shrink-0" id="history-sidebar">
      {/* Sidebar Header */}
      <div className="p-4 border-b border-slate-800/80 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <BarChart3 className="w-4 h-4 text-emerald-400" />
          <h2 className="font-display font-bold text-white text-xs uppercase tracking-widest">Research Vault</h2>
        </div>
        <button
          onClick={onNewResearch}
          className="text-[10px] bg-emerald-500 hover:bg-emerald-400 text-black font-extrabold py-1.5 px-3 rounded-xl tracking-wider uppercase transition-all duration-300"
          id="btn-new-research"
        >
          New Run
        </button>
      </div>

      {/* Quick Statistics Mini-Dashboard */}
      {total > 0 && (
        <div className="p-4 bg-[#050505]/40 border-b border-slate-800/80">
          <div className="text-[9px] uppercase tracking-widest font-mono text-slate-500 mb-2.5 flex items-center gap-1.5 font-bold">
            <TrendingUp className="w-3.5 h-3.5 text-slate-500" />
            Decision Distribution
          </div>
          <div className="grid grid-cols-3 gap-2 text-center text-xs">
            <div className="bg-[#050505] p-2.5 rounded-2xl border border-slate-800/60">
              <span className="text-emerald-400 font-extrabold block text-sm">{investCount}</span>
              <span className="text-[8px] font-mono font-semibold text-slate-500 uppercase tracking-wider block mt-0.5">BUY</span>
            </div>
            <div className="bg-[#050505] p-2.5 rounded-2xl border border-slate-800/60">
              <span className="text-amber-400 font-extrabold block text-sm">{holdCount}</span>
              <span className="text-[8px] font-mono font-semibold text-slate-500 uppercase tracking-wider block mt-0.5">HOLD</span>
            </div>
            <div className="bg-[#050505] p-2.5 rounded-2xl border border-slate-800/60">
              <span className="text-rose-400 font-extrabold block text-sm">{passCount}</span>
              <span className="text-[8px] font-mono font-semibold text-slate-500 uppercase tracking-wider block mt-0.5">PASS</span>
            </div>
          </div>
        </div>
      )}

      {/* Saved Reports List */}
      <div className="flex-1 overflow-y-auto p-3 space-y-2">
        <div className="text-[9px] uppercase tracking-widest font-mono text-slate-500 mb-1 px-1 font-bold">
          Historical Audits ({total})
        </div>

        {reports.length === 0 ? (
          <div className="text-center py-8 px-4 text-slate-500 flex flex-col items-center justify-center h-48 border border-dashed border-slate-800 rounded-3xl">
            <FileText className="w-7 h-7 mb-2 text-slate-700" />
            <p className="text-[11px] font-mono">No reports saved yet.</p>
            <p className="text-[9px] mt-1 text-slate-600 leading-relaxed max-w-[160px] mx-auto">Analyze a company to persist research metrics.</p>
          </div>
        ) : (
          reports.map((report) => (
            <div
              key={report.id}
              className={`group flex items-center justify-between p-3 rounded-2xl border transition-all duration-300 cursor-pointer text-left ${
                selectedId === report.id
                  ? "bg-slate-800/40 border-emerald-500/40 shadow-inner"
                  : "bg-slate-950/20 border-slate-800/80 hover:bg-slate-800/20 hover:border-slate-700"
              }`}
              onClick={() => onSelectReport(report.id)}
              id={`report-item-${report.id}`}
            >
              <div className="flex-1 min-w-0 pr-2">
                <div className="flex items-center gap-1.5 mb-1.5">
                  <span className="font-display font-bold text-slate-200 truncate text-xs">
                    {report.companyInfo.name}
                  </span>
                  <span className="font-mono text-[9px] bg-slate-900 text-slate-400 px-1.5 py-0.5 rounded border border-slate-800">
                    {report.companyInfo.ticker}
                  </span>
                </div>
                <div className="flex items-center gap-2 text-[9px] text-slate-500 font-mono">
                  <span>{new Date(report.timestamp).toLocaleDateString()}</span>
                  <span className={`px-1.5 py-0.5 rounded text-[8px] font-bold ${decisionBadgeStyle(report.thesis.decision)}`}>
                    {report.thesis.decision}
                  </span>
                </div>
              </div>
              
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onDeleteReport(report.id);
                }}
                className="text-slate-600 hover:text-rose-400 p-1.5 rounded opacity-0 group-hover:opacity-100 transition-opacity"
                title="Delete Report"
                id={`delete-${report.id}`}
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          ))
        )}
      </div>

      {/* Sidebar Footer */}
      {reports.length > 0 && (
        <div className="p-3.5 border-t border-slate-800/80 bg-[#050505]/40 flex items-center justify-between">
          <button
            onClick={onClearAll}
            className="text-[10px] text-slate-500 hover:text-rose-400 font-mono flex items-center gap-1.5 font-bold uppercase tracking-wider"
            id="btn-clear-all"
          >
            <Trash2 className="w-3.5 h-3.5" /> Clear Vault
          </button>
        </div>
      )}
    </div>
  );
}
