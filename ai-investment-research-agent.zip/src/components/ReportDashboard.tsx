import { ResearchReport, CompetitorMetric } from "../types.js";
import { 
  TrendingUp, TrendingDown, Shield, Award, AlertTriangle, 
  Layers, ExternalLink, Calendar, Check, DollarSign, 
  Lightbulb, Activity, ArrowUpRight, BarChart3, HelpCircle 
} from "lucide-react";
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid, Legend } from "recharts";

interface ReportDashboardProps {
  report: ResearchReport;
}

export default function ReportDashboard({ report }: ReportDashboardProps) {
  const { companyInfo, financials, swot, news, competitors, thesis, sources } = report;

  // Formatting helper for currency/numbers
  const formatDecisionColor = (decision: string) => {
    switch (decision) {
      case "INVEST":
        return "text-emerald-400 border-emerald-500/30 bg-emerald-500/10";
      case "HOLD":
        return "text-amber-400 border-amber-500/30 bg-amber-500/10";
      case "PASS":
        return "text-rose-400 border-rose-500/30 bg-rose-500/10";
      default:
        return "text-slate-400 border-slate-700 bg-slate-800/10";
    }
  };

  const getSentimentColor = (sentiment: string) => {
    switch (sentiment) {
      case "Bullish":
        return "bg-emerald-500/10 text-emerald-400 border-emerald-500/20";
      case "Bearish":
        return "bg-rose-500/10 text-rose-400 border-rose-500/20";
      default:
        return "bg-slate-500/10 text-slate-400 border-slate-500/20";
    }
  };

  // Convert financials to chart data
  const chartData = financials.metrics.map(metric => {
    const cleanNum = (str: string) => {
      const parsed = parseFloat(str.replace(/[^0-9.-]/g, ''));
      return isNaN(parsed) ? 0 : parsed;
    };
    return {
      name: metric.year,
      Revenue: cleanNum(metric.revenue),
      NetIncome: cleanNum(metric.netIncome)
    };
  }).reverse(); // Order chronologically

  return (
    <div className="max-w-7xl mx-auto p-4 md:p-8 space-y-6 animate-fade-in" id="report-dashboard">
      
      {/* 1. Header & Quick Citation Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800/60 pb-6">
        <div>
          <div className="flex items-center gap-2 mb-2 font-mono text-[10px] text-slate-500 uppercase tracking-widest">
            <Calendar className="w-3.5 h-3.5 text-emerald-400" />
            <span>Generated on {new Date(report.timestamp).toLocaleDateString()}</span>
            <span className="text-slate-700">•</span>
            <span>Autonomous Equity Agent v1.2</span>
          </div>
          <div className="flex items-baseline gap-3">
            <h1 className="font-display text-3xl md:text-4xl font-extrabold text-white tracking-tight">
              {companyInfo.name}
            </h1>
            <span className="font-mono text-xs bg-slate-800/80 text-slate-300 py-1 px-2.5 rounded-lg font-bold">
              {companyInfo.ticker}
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-2 font-mono">
            Sector: <span className="text-slate-300 font-semibold">{companyInfo.sector}</span>
          </p>
        </div>

        {/* Quick Market Profile Stats */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-900/30 p-3 rounded-2xl border border-slate-800/80 shadow-inner">
          <div className="px-3 py-1">
            <span className="text-[9px] text-slate-500 uppercase tracking-wider font-bold block">Price</span>
            <span className="text-slate-100 font-semibold text-sm">{companyInfo.currentPrice}</span>
          </div>
          <div className="px-3 py-1">
            <span className="text-[9px] text-slate-500 uppercase tracking-wider font-bold block">Change</span>
            <span className={`text-xs font-semibold flex items-center gap-0.5 ${companyInfo.priceChange.startsWith('-') ? 'text-rose-400' : 'text-emerald-400'}`}>
              {companyInfo.priceChange} ({companyInfo.priceChangePercent})
            </span>
          </div>
          <div className="px-3 py-1">
            <span className="text-[9px] text-slate-500 uppercase tracking-wider font-bold block">Market Cap</span>
            <span className="text-slate-100 font-semibold text-sm">{companyInfo.marketCap}</span>
          </div>
          <div className="px-3 py-1">
            <span className="text-[9px] text-slate-500 uppercase tracking-wider font-bold block">P/E Ratio</span>
            <span className="text-slate-100 font-semibold text-sm">{companyInfo.peRatio}</span>
          </div>
        </div>
      </div>

      {/* 2. Top-Level Decision and Thesis Summary Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Big Decision Panel */}
        <div className={`lg:col-span-5 border rounded-3xl p-6 md:p-8 flex flex-col justify-between shadow-2xl relative overflow-hidden transition-all duration-300 ${
          thesis.decision === 'INVEST' 
            ? 'bg-gradient-to-br from-emerald-950/30 to-slate-900/50 border-emerald-500/30' 
            : thesis.decision === 'HOLD'
            ? 'bg-gradient-to-br from-amber-950/20 to-slate-900/50 border-amber-500/30'
            : 'bg-gradient-to-br from-rose-950/20 to-slate-900/50 border-rose-500/30'
        }`}>
          <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/5 rounded-full blur-2xl"></div>
          
          <div className="space-y-6">
            <div className="flex items-center gap-3">
              <span className={`px-3 py-1 rounded-full text-[9px] font-bold uppercase tracking-widest ${
                thesis.decision === 'INVEST'
                  ? 'bg-emerald-500 text-black'
                  : thesis.decision === 'HOLD'
                  ? 'bg-amber-500 text-black'
                  : 'bg-rose-500 text-white'
              }`}>
                Agent Recommendation
              </span>
              <div className="flex gap-1">
                <div className={`w-1 h-1 rounded-full ${thesis.decision === 'INVEST' ? 'bg-emerald-500' : 'bg-slate-500'}`}></div>
                <div className={`w-1 h-1 rounded-full ${thesis.decision === 'INVEST' ? 'bg-emerald-500' : 'bg-slate-500'}`}></div>
                <div className="w-1 h-1 rounded-full bg-slate-500/30"></div>
              </div>
            </div>
            
            <div className="space-y-1">
              <h2 className="text-5xl md:text-6xl font-black tracking-tighter text-white uppercase leading-none">
                {thesis.decision === 'INVEST' ? 'STRONG BUY' : thesis.decision === 'HOLD' ? 'HOLD' : 'PASS'}
              </h2>
              <div className="flex items-baseline gap-1 mt-1">
                <span className="text-[10px] text-slate-500 uppercase font-mono block">Target Estimate:</span>
                <span className="text-emerald-400 font-bold text-sm font-mono">{thesis.targetPriceEstimate}</span>
              </div>
            </div>

            {/* Conviction Score Speedometer Meter */}
            <div className="space-y-2 pt-2">
              <div className="flex justify-between items-baseline text-xs">
                <span className="text-slate-400 font-mono text-[9px] uppercase tracking-wider font-bold">Conviction Index</span>
                <span className="text-slate-200 font-bold font-mono">{thesis.convictionScore} <span className="text-slate-500 text-[10px]">/ 10</span></span>
              </div>
              <div className="h-1.5 w-full bg-slate-950 rounded-full overflow-hidden">
                <div 
                  className={`h-full rounded-full transition-all duration-1000 ${
                    thesis.decision === 'INVEST' ? 'bg-emerald-500' : thesis.decision === 'HOLD' ? 'bg-amber-500' : 'bg-rose-500'
                  }`}
                  style={{ width: `${thesis.convictionScore * 10}%` }}
                ></div>
              </div>
            </div>
          </div>

          <div className="mt-8 pt-4 border-t border-slate-800/80">
            <span className="text-[10px] text-slate-500 uppercase font-mono tracking-wider font-bold block">Strategic Recommendation</span>
            <p className="text-xs text-slate-300 mt-1.5 font-sans leading-relaxed">
              {thesis.strategyRecommendation}
            </p>
          </div>
        </div>

        {/* Investment Thesis Narrative */}
        <div className="lg:col-span-7 bg-slate-900/40 border border-slate-800 rounded-3xl p-6 md:p-8 flex flex-col justify-between shadow-lg">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <Award className="w-4 h-4 text-emerald-400" />
              <span className="text-xs text-slate-500 uppercase font-bold tracking-widest">Executive Investment Thesis</span>
            </div>
            
            <div className="text-slate-300 text-[13px] md:text-[14px] leading-relaxed space-y-4 font-sans">
              {thesis.thesisSummary.split('\n\n').map((para, i) => (
                <p key={i} className="text-slate-300">{para}</p>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4 mt-6 pt-4 border-t border-slate-800/80 text-xs">
            <div>
              <span className="text-[10px] text-slate-500 uppercase font-mono block">52-Week High/Low</span>
              <span className="text-slate-300 font-semibold block mt-0.5">{companyInfo.fiftyTwoWeekRange}</span>
            </div>
            <div>
              <span className="text-[10px] text-slate-500 uppercase font-mono block">Dividend Yield</span>
              <span className="text-slate-300 font-semibold block mt-0.5">{companyInfo.dividendYield}</span>
            </div>
          </div>
        </div>
      </div>

      {/* 3. Financial Analysis Section (Recharts Chart + Mini Stats Grid) */}
      <div className="bg-slate-900/40 border border-slate-800 rounded-3xl p-6 md:p-8 shadow-lg space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800/80 pb-4">
          <div className="flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-emerald-400" />
            <h3 className="text-xs uppercase font-bold tracking-widest text-slate-500">Financial Performance & Fundamental Audit</h3>
          </div>
          <span className="text-[10px] font-mono text-slate-500">values compiled in USD (Billions/Millions)</span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Revenue Chart */}
          <div className="lg:col-span-7 h-64 bg-[#050505]/60 p-4 rounded-2xl border border-slate-800/80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="name" stroke="#64748b" fontSize={11} tickLine={false} />
                <YAxis stroke="#64748b" fontSize={11} tickLine={false} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', color: '#f1f5f9', borderRadius: '8px', fontSize: '12px' }} 
                  labelStyle={{ fontWeight: 'bold', color: '#10b981' }}
                />
                <Legend wrapperStyle={{ fontSize: '11px', marginTop: '5px' }} />
                <Bar dataKey="Revenue" fill="#10b981" radius={[4, 4, 0, 0]} name="Annual Revenue" />
                <Bar dataKey="NetIncome" fill="#3b82f6" radius={[4, 4, 0, 0]} name="Net Income" />
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Key Metrics and Financial Summary */}
          <div className="lg:col-span-5 flex flex-col justify-between space-y-4">
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="bg-[#050505]/40 p-3 rounded-2xl border border-slate-800/60">
                <span className="text-slate-500 text-[10px] block font-mono uppercase">Debt to Equity</span>
                <span className="text-slate-200 font-bold block mt-0.5 text-sm">{financials.debtToEquity}</span>
              </div>
              <div className="bg-[#050505]/40 p-3 rounded-2xl border border-slate-800/60">
                <span className="text-slate-500 text-[10px] block font-mono uppercase">Free Cash Flow</span>
                <span className="text-slate-200 font-bold block mt-0.5 text-sm">{financials.freeCashFlow}</span>
              </div>
              <div className="bg-[#050505]/40 p-3 rounded-2xl border border-slate-800/60 col-span-2">
                <span className="text-slate-500 text-[10px] block font-mono uppercase">P/E Compared to Industry Avg</span>
                <span className="text-slate-200 font-bold block mt-0.5 text-xs text-emerald-400">{financials.peVsIndustry}</span>
              </div>
            </div>

            <div className="bg-[#050505]/40 p-3.5 rounded-2xl border border-slate-800/60">
              <span className="text-slate-400 text-[10px] font-mono uppercase block mb-1.5">Financial Health Audit Narrative</span>
              <p className="text-xs text-slate-300 leading-relaxed font-sans">
                {financials.financialHealthSummary}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* 4. SWOT Matrix Grid */}
      <div className="space-y-3">
        <div className="flex items-center gap-2 px-1">
          <Layers className="w-5 h-5 text-emerald-400" />
          <h3 className="text-xs uppercase font-bold tracking-widest text-slate-500">SWOT Matrix</h3>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          
          {/* Strengths */}
          <div className="bg-slate-900/40 border border-emerald-500/20 rounded-3xl p-6 space-y-3 relative overflow-hidden">
            <div className="absolute top-0 right-0 p-1 bg-emerald-500/10 text-emerald-400 font-bold text-[9px] font-mono rounded-bl-lg">STRENGTHS</div>
            <div className="flex items-center gap-2 text-emerald-400 border-b border-slate-800 pb-2">
              <Check className="w-4 h-4 shrink-0" />
              <span className="font-display font-semibold text-xs sm:text-sm">Strategic Moat & Internal Strengths</span>
            </div>
            <ul className="space-y-2 text-slate-300 text-xs list-disc pl-4 font-sans leading-relaxed">
              {swot.strengths.map((str, idx) => <li key={idx}>{str}</li>)}
            </ul>
          </div>

          {/* Weaknesses */}
          <div className="bg-slate-900/40 border border-rose-500/20 rounded-3xl p-6 space-y-3 relative overflow-hidden">
            <div className="absolute top-0 right-0 p-1 bg-rose-500/10 text-rose-400 font-bold text-[9px] font-mono rounded-bl-lg">WEAKNESSES</div>
            <div className="flex items-center gap-2 text-rose-400 border-b border-slate-800 pb-2">
              <AlertTriangle className="w-4 h-4 shrink-0" />
              <span className="font-display font-semibold text-xs sm:text-sm">Vulnerabilities & Internal Constraints</span>
            </div>
            <ul className="space-y-2 text-slate-300 text-xs list-disc pl-4 font-sans leading-relaxed">
              {swot.weaknesses.map((str, idx) => <li key={idx}>{str}</li>)}
            </ul>
          </div>

          {/* Opportunities */}
          <div className="bg-slate-900/40 border border-blue-500/20 rounded-3xl p-6 space-y-3 relative overflow-hidden">
            <div className="absolute top-0 right-0 p-1 bg-blue-500/10 text-blue-400 font-bold text-[9px] font-mono rounded-bl-lg">OPPORTUNITIES</div>
            <div className="flex items-center gap-2 text-blue-400 border-b border-slate-800 pb-2">
              <Lightbulb className="w-4 h-4 shrink-0" />
              <span className="font-display font-semibold text-xs sm:text-sm">Growth Drivers & External Opportunities</span>
            </div>
            <ul className="space-y-2 text-slate-300 text-xs list-disc pl-4 font-sans leading-relaxed">
              {swot.opportunities.map((str, idx) => <li key={idx}>{str}</li>)}
            </ul>
          </div>

          {/* Threats */}
          <div className="bg-slate-900/40 border border-amber-500/20 rounded-3xl p-6 space-y-3 relative overflow-hidden">
            <div className="absolute top-0 right-0 p-1 bg-amber-500/10 text-amber-400 font-bold text-[9px] font-mono rounded-bl-lg">THREATS</div>
            <div className="flex items-center gap-2 text-amber-400 border-b border-slate-800 pb-2">
              <Shield className="w-4 h-4 shrink-0" />
              <span className="font-display font-semibold text-xs sm:text-sm">Macro Headwinds & Competitor Threats</span>
            </div>
            <ul className="space-y-2 text-slate-300 text-xs list-disc pl-4 font-sans leading-relaxed">
              {swot.threats.map((str, idx) => <li key={idx}>{str}</li>)}
            </ul>
          </div>

        </div>
      </div>

      {/* 5. Competitor Matrix & News sentiment */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Competitor Grid */}
        <div className="lg:col-span-7 bg-slate-900/40 border border-slate-800 rounded-3xl p-6 space-y-4 shadow-lg">
          <div className="flex items-center gap-2 border-b border-slate-800/80 pb-2.5">
            <Activity className="w-4 h-4 text-emerald-400" />
            <h3 className="text-xs uppercase font-bold tracking-widest text-slate-500">Competitive Benchmark Matrix</h3>
          </div>
          
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-800 text-slate-500 font-mono">
                  <th className="pb-2 font-medium">Company</th>
                  <th className="pb-2 font-medium">Cap</th>
                  <th className="pb-2 font-medium">P/E</th>
                  <th className="pb-2 font-medium">Growth</th>
                  <th className="pb-2 font-medium">Margin</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/40">
                {/* Active company */}
                <tr className="text-emerald-300 font-semibold bg-emerald-500/[0.02]">
                  <td className="py-2">{companyInfo.name} ({companyInfo.ticker})</td>
                  <td className="py-2">{companyInfo.marketCap}</td>
                  <td className="py-2">{companyInfo.peRatio}</td>
                  <td className="py-2">{financials.metrics[0]?.revenueGrowth || "N/A"}</td>
                  <td className="py-2">{financials.metrics[0]?.operatingMargin || "N/A"}</td>
                </tr>
                {/* Competitors */}
                {competitors.map((comp, idx) => (
                  <tr key={idx} className="text-slate-300">
                    <td className="py-2">{comp.companyName} ({comp.ticker})</td>
                    <td className="py-2">{comp.marketCap}</td>
                    <td className="py-2">{comp.peRatio}</td>
                    <td className="py-2">{comp.revenueGrowth}</td>
                    <td className="py-2">{comp.profitMargin}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Bull/Bear Catalysts & Risks */}
        <div className="lg:col-span-5 bg-slate-900/40 border border-slate-800 rounded-3xl p-6 space-y-4 shadow-lg">
          <div className="flex items-center justify-between border-b border-slate-800/80 pb-2.5">
            <span className="font-display font-semibold text-slate-200 text-sm flex items-center gap-1.5">
              <ArrowUpRight className="w-4 h-4 text-emerald-400" /> Catalysts vs Risks
            </span>
          </div>

          <div className="space-y-4 text-xs">
            {/* Catalysts list */}
            <div className="space-y-1.5">
              <span className="text-emerald-400 font-semibold block text-[10px] font-mono uppercase tracking-wide">Key Positives / Bull Catalysts</span>
              <ul className="space-y-1 text-slate-300 pl-3 list-disc">
                {thesis.keyCatalysts.slice(0, 3).map((item, i) => <li key={i}>{item}</li>)}
              </ul>
            </div>
            
            {/* Risks list */}
            <div className="space-y-1.5">
              <span className="text-rose-400 font-semibold block text-[10px] font-mono uppercase tracking-wide">Key Negatives / Bear Risks</span>
              <ul className="space-y-1 text-slate-300 pl-3 list-disc">
                {thesis.keyRisks.slice(0, 3).map((item, i) => <li key={i}>{item}</li>)}
              </ul>
            </div>
          </div>
        </div>

      </div>

      {/* 6. Media and Social Sentiment Monitor */}
      <div className="bg-slate-900/40 border border-slate-800 rounded-3xl p-6 shadow-lg space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800/80 pb-2.5">
          <h3 className="text-xs uppercase font-bold tracking-widest text-slate-500">Media and SEC Filings Monitor</h3>
          <span className="text-[10px] bg-slate-950 font-mono text-emerald-500 py-0.5 px-2 rounded border border-slate-800">
            Real-Time Crawler Active
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {news.map((item, idx) => (
            <div key={idx} className="bg-[#050505]/40 p-4.5 rounded-2xl border border-slate-800 flex flex-col justify-between">
              <div>
                <div className="flex justify-between items-start gap-1">
                  <span className="text-[10px] text-slate-500 font-mono">{item.source}</span>
                  <span className={`text-[9px] font-bold font-mono px-1.5 py-0.5 rounded-full border ${getSentimentColor(item.sentiment)}`}>
                    {item.sentiment}
                  </span>
                </div>
                <h4 className="text-xs font-bold text-slate-200 mt-2 line-clamp-2">
                  {item.title}
                </h4>
                <p className="text-slate-400 text-[11px] leading-relaxed mt-1.5">
                  {item.summary}
                </p>
              </div>
              
              {item.url && (
                <a 
                  href={item.url} 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="text-emerald-400 hover:text-emerald-300 text-[10px] mt-3.5 inline-flex items-center gap-1 font-mono transition"
                >
                  View Article <ExternalLink className="w-3 h-3" />
                </a>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* 7. Grounding Citations */}
      {sources.length > 0 && (
        <div className="bg-[#050505]/50 border border-slate-800 rounded-2xl p-5">
          <h4 className="text-slate-500 text-[10px] font-mono mb-3 uppercase tracking-wider font-bold">
            Citations & Verification Sources ({sources.length})
          </h4>
          <div className="flex flex-wrap gap-2">
            {sources.map((source, idx) => (
              <a
                key={idx}
                href={source.uri}
                target="_blank"
                referrerPolicy="no-referrer"
                className="text-[10px] text-slate-400 bg-slate-900/60 border border-slate-800 hover:border-slate-700 hover:text-slate-200 px-3 py-1.5 rounded-xl transition flex items-center gap-1.5 max-w-xs truncate"
                title={source.title}
              >
                <ExternalLink className="w-3 h-3 text-emerald-500 shrink-0" />
                <span className="truncate">{source.title}</span>
              </a>
            ))}
          </div>
        </div>
      )}

    </div>
  );
}
