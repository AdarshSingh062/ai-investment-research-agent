import { WatchlistItem, DecisionType } from "../types.js";
import { TrendingUp, Plus, ShieldCheck, Eye, Trash2, ArrowUpRight, Award, PlusCircle } from "lucide-react";

interface WatchlistProps {
  items: WatchlistItem[];
  onSelectItem: (companyName: string) => void;
  onRemoveItem: (id: string) => void;
  onExploreDefault: (companyName: string) => void;
}

export default function Watchlist({ items, onSelectItem, onRemoveItem, onExploreDefault }: WatchlistProps) {
  
  const getBadgeStyle = (decision: DecisionType) => {
    switch (decision) {
      case "INVEST":
        return "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20";
      case "HOLD":
        return "bg-amber-500/10 text-amber-400 border border-amber-500/20";
      case "PASS":
        return "bg-rose-500/10 text-rose-400 border border-rose-500/20";
    }
  };

  const defaultSuggestions = [
    { name: "Nvidia", ticker: "NVDA", desc: "Leading semiconductor & AI hardware giant" },
    { name: "Apple", ticker: "AAPL", desc: "Consumer tech leader with massive services moat" },
    { name: "Tesla", ticker: "TSLA", desc: "EV and autonomous driving technology disruptor" },
    { name: "Eli Lilly", ticker: "LLY", desc: "Healthcare innovator in weight loss & Alzheimer's solutions" },
  ];

  return (
    <div className="max-w-7xl mx-auto p-4 md:p-8 space-y-8 animate-fade-in" id="watchlist-panel">
      {/* Suggestions Section */}
      <div className="bg-gradient-to-br from-emerald-950/20 to-slate-900/40 border border-emerald-500/20 p-6 md:p-8 rounded-3xl relative overflow-hidden shadow-xl">
        <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/[0.02] rounded-full blur-3xl -mr-10 -mt-10"></div>
        <div className="relative">
          <div className="flex items-center gap-3 mb-2">
            <Award className="w-5 h-5 text-emerald-400" />
            <h3 className="font-display font-bold text-white text-sm uppercase tracking-widest">Suggested Research Targets</h3>
          </div>
          <p className="text-xs text-slate-400 max-w-xl leading-relaxed">
            Deploy your autonomous research agents onto top-tier market movers with a single click. The agent compiles web grounding inputs in under 40 seconds.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mt-6">
            {defaultSuggestions.map((sug, idx) => (
              <div
                key={idx}
                onClick={() => onExploreDefault(sug.name)}
                className="group bg-[#050505]/60 hover:bg-[#050505] border border-slate-800 hover:border-emerald-500/30 p-4 rounded-2xl cursor-pointer transition-all duration-300 flex flex-col justify-between shadow-inner"
                id={`sug-item-${sug.ticker}`}
              >
                <div>
                  <div className="flex items-center justify-between">
                    <span className="font-display font-bold text-white text-sm tracking-tight">{sug.name}</span>
                    <span className="font-mono text-[9px] bg-slate-900 text-slate-400 py-0.5 px-2 rounded-md border border-slate-800">
                      {sug.ticker}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-2 leading-relaxed">
                    {sug.desc}
                  </p>
                </div>
                <div className="mt-4 flex items-center gap-1.5 text-[10px] text-emerald-400 font-mono font-medium opacity-75 group-hover:opacity-100 transition-opacity">
                  Deploy Agent <ArrowUpRight className="w-3.5 h-3.5" />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Active Watchlist section */}
      <div className="space-y-4">
        <div className="flex items-center gap-2 px-1">
          <TrendingUp className="w-5 h-5 text-emerald-400" />
          <h3 className="font-display font-bold tracking-widest uppercase text-[11px] text-slate-400">Equity Watchlist ({items.length})</h3>
        </div>

        {items.length === 0 ? (
          <div className="text-center py-16 px-4 border border-dashed border-slate-800 rounded-3xl bg-slate-900/10 flex flex-col items-center justify-center">
            <PlusCircle className="w-9 h-9 text-slate-600 mb-3" />
            <h4 className="text-sm font-semibold text-slate-400">Your Watchlist is Empty</h4>
            <p className="text-xs text-slate-500 mt-1 max-w-sm leading-relaxed">
              Launch a search for any global equity above. Once research completes, results automatically pin to this interactive bento watchlist.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {items.map((item) => (
              <div
                key={item.id}
                className="bg-slate-900/40 border border-slate-800 rounded-3xl p-5 flex flex-col justify-between shadow-lg hover:border-slate-700/80 transition-all duration-300"
                id={`watch-item-${item.ticker}`}
              >
                <div>
                  <div className="flex items-start justify-between gap-2 border-b border-slate-800/40 pb-3">
                    <div>
                      <h4 className="font-display font-bold text-white text-base tracking-tight">{item.companyName}</h4>
                      <span className="font-mono text-xs text-slate-400 font-semibold">{item.ticker}</span>
                    </div>
                    <span className={`px-2.5 py-1 rounded-lg text-[10px] font-bold tracking-wide border ${getBadgeStyle(item.decision)}`}>
                      {item.decision}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-3 mt-4 text-xs">
                    <div className="bg-[#050505]/40 p-3 rounded-2xl border border-slate-800/60">
                      <span className="text-[9px] text-slate-500 font-mono block uppercase tracking-wider">Last Price</span>
                      <span className="text-slate-200 font-bold block mt-0.5">{item.currentPrice}</span>
                    </div>
                    <div className="bg-[#050505]/40 p-3 rounded-2xl border border-slate-800/60">
                      <span className="text-[9px] text-slate-500 font-mono block uppercase tracking-wider">Conviction</span>
                      <span className="text-emerald-400 font-bold block mt-0.5">{item.convictionScore} <span className="text-slate-600 font-normal text-[10px]">/ 10</span></span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between border-t border-slate-800/40 mt-5 pt-3.5 text-xs font-mono">
                  <span className="text-[10px] text-slate-500">
                    Added {new Date(item.timestamp).toLocaleDateString()}
                  </span>
                  
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => onSelectItem(item.companyName)}
                      className="px-3 py-1.5 rounded-xl bg-slate-950 hover:bg-slate-900 text-slate-200 hover:text-emerald-400 border border-slate-800 transition flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider"
                      title="Load Report"
                      id={`btn-load-${item.ticker}`}
                    >
                      <Eye className="w-3.5 h-3.5" /> Report
                    </button>
                    <button
                      onClick={() => onRemoveItem(item.id)}
                      className="text-slate-500 hover:text-rose-400 p-2 rounded-xl hover:bg-slate-900/40 transition"
                      title="Remove from Watchlist"
                      id={`btn-remove-${item.ticker}`}
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
